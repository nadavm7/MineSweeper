package com.example.kingmanne;

public interface Comperable {
}
