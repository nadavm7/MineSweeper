package com.example.kingmanne;

public class MotionToast {
}
