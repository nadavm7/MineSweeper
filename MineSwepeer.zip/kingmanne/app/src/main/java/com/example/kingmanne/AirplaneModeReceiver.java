package com.example.kingmanne;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import io.github.muddz.styleabletoast.StyleableToast;

/**
 * Created by ADMIN on 7/19/2016.
 */
public class AirplaneModeReceiver extends BroadcastReceiver {
    private static final String TAG = "AirplaneModeReceiver";
    boolean state;
    private ImageView imageview;
    //Intent intent1;
    SaveSettings saveSettings;

    @Override
    public void onReceive(Context context, Intent intent) {
        state = intent.getBooleanExtra("state", false);
        StringBuilder sb = new StringBuilder();
        sb.append("Action: " + intent.getAction() + "\n");
        sb.append("URI: " + intent.toUri(Intent.URI_INTENT_SCHEME) + "\n");
        String log = sb.toString();
        Log.d(TAG, log);
        if(state)
        StyleableToast.makeText(context,"AirPlane mode is on", R.style.Warning).show();
        else{
            StyleableToast.makeText(context,"AirPlane mode is off", R.style.Warning).show();
        }


//         saveSettings = new SaveSettings(this);
//        //String onf = saveSettings.getStrKeysonf();
//                if (state == true) {
//                 saveSettings.setStrKeysonf("on");
//                }
//                else {
//                    saveSettings.setStrKeysonf("off");
//                }
    }

//    public void onOrOff() {
//        Intent intent1 = new Intent(this, MainActivity.class);
//        if (state == true) {
////             = new Intent(this, MainActivity.class);
//            String WL = "on";
//            intent1.putExtra("onf", WL);
//            startActivity(intent1);
//        } else {
////            intent1 = new Intent(this, MainActivity.class);
//            String Www = "off";
//            intent1.putExtra("onf", Www);
//            startActivity(intent1);
//        }
//
//    }
}
