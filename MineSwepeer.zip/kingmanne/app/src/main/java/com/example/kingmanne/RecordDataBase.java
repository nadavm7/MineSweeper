package com.example.kingmanne;

import static android.app.DownloadManager.COLUMN_ID;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;

public class RecordDataBase extends SQLiteOpenHelper {

    private static final String DATABASENAME = "nadav.db";
    private static final String TABLE_RECORD = "tblRecords";
    private static final int DATABASEVERSION = 2;

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TIME = "time";
    private static final String COLUMN_WINNER = "winner";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_NICK_NAME = "nick_mame";
    //private static final String COLUMN_BTIMAP = "bitmap"; //TODO

    private static final String[] allColumns = {COLUMN_ID, COLUMN_NAME, COLUMN_NICK_NAME, COLUMN_WINNER, COLUMN_TIME};

    private static final String CREATE_TABLE_CUSTOMER = "CREATE TABLE IF NOT EXISTS " +
            TABLE_RECORD + "(" +
            COLUMN_ID + " INTEGER PRIMARY KEY," +
            COLUMN_NAME + " TEXT," +
            COLUMN_NICK_NAME + " TEXT," +
            COLUMN_WINNER + " TEXT ," +
            COLUMN_TIME + " INTEGER );";
    private static ArrayList<Record> records; //////////TODO 4+5
    private static RecordDataBase instance;//////////TODO 7
    private static SQLiteDatabase database; // access to table

    public RecordDataBase(@Nullable Context context) {
        super(context, DATABASENAME, null, DATABASEVERSION);
        //getAllRecords();//////////TODO 6
        //////////TODO 8 = last
        if (instance == null)
            if (records == null)
                getAllRecords();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_CUSTOMER);
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_RECORD);
        onCreate(sqLiteDatabase);
    }

    public Record createRecord(Record t) {
        database = getWritableDatabase(); // get access to write the database
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, t.getName());
        values.put(COLUMN_NICK_NAME, t.getNickName());
        values.put(COLUMN_WINNER, t.getWinner());
        values.put(COLUMN_TIME, t.getTime());
        long id = database.insert(TABLE_RECORD, null, values);
        t.setId(id);
        database.close();
        return t;
    }

//    public void deleteRecordByRow(long id) {
//        database = getWritableDatabase(); // get access to read the data
//        database.delete(TABLE_RECORD, COLUMN_TIME + " = " + id, null);
//        database.close(); // close the database
//    }
    public void deleteRecordByRow(long id) {
        database = getWritableDatabase(); // get access to read the data
        database.delete(TABLE_RECORD, COLUMN_ID + " = " + id, null);
        database.close(); // close the database
       // records.remove(pos);
    }


    public ArrayList<Record> getAllRecords() {   //////////TODO--
        database = getReadableDatabase(); // get access to read the database
        //////////TODO 4+5 ArrayList<Player> players = new ArrayList<>();
        records = new ArrayList<Record>();
        String sortOrder = COLUMN_TIME + " DESC"; // sorting by score
        Cursor cursor = database.query(TABLE_RECORD, allColumns, null, null, null, null, sortOrder); // cursor points at a certain row

        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                String nickName = cursor.getString(cursor.getColumnIndex(COLUMN_NICK_NAME));
                String winner = cursor.getString(cursor.getColumnIndex(COLUMN_WINNER));
                int time = cursor.getInt(cursor.getColumnIndex(COLUMN_TIME));
                long id = cursor.getLong(cursor.getColumnIndex(COLUMN_ID));
                //Record record = new Record(price, title, subtitle, id);
                Record record = new Record(time,name , nickName , winner,id);
                records.add(record);
            }
        }
        database.close();
        Collections.sort(records); //////////TODO 1
        return records;
    }

    //////////TODO 2
    public void updateByRow(Record record) {
        database = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, record.getId());
        values.put(COLUMN_NAME, record.getName());
        values.put(COLUMN_NICK_NAME, record.getNickName());
        values.put(COLUMN_TIME, record.getTime());
        database.update(TABLE_RECORD, values, COLUMN_ID + "=" + record.getId(), null);
        database.close();
    }

    //////////TODO 3
//    public void setRecord(Toy toy) {
//        Toy current = null;
//        for (Toy t :toy) {   //////////TODO--
//            if (t.getTitle().equalsIgnoreCase(toy.getTitle())) {
//                current = t;
//                break;
//            }
//        }
//        if (current == null)
//            createRecord(toy);
//        else {
//            //current.AddScore();
//            updateByRow(current);
//        }
//    }
}

