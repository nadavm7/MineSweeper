package com.example.kingmanne;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class RecordAdapter extends ArrayAdapter<Record> {
    Context context;
    List<Record> objects;
    //String

    public RecordAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<Record> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;

    }

    @NonNull
    @Override
    //position מיקום התא ברשימה
    //parent ה listVew
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);

        //המרנו את ה context לאקטיביטי על מנת להשתמש ב Inflater.
        LayoutInflater layoutInflater = ((Activity) context).getLayoutInflater();

        //יוצרים תא, אותו תחזיר הפונקציה
        //"ניפחנו" את ה XML שבנינו לכל תא וכך הפכנו את ה XML של כל תא ל View
        View view = layoutInflater.inflate(R.layout.custom_layout, parent, false);
       // SaveSettings saveSettings = new SaveSettings(this);
        if (SaveSettings.getStrWoLC().equals("Losser") ) {
            Log.e("nadav", SaveSettings.getStrWoLC());
            Log.e("nadav1", String.valueOf(position));
            view.setBackgroundColor(Color.parseColor("#FA0000"));
        } else {
            view.setBackgroundColor(Color.parseColor("#00FF0A"));
        }
//        if (saveSettings.getStrKeysonf().equals("on")) {
//            WorL.setText("air p mode is onnnnnnnnnnn");
//
//        } else {
//            WorL.setText("air p mode is offfffffffff ");
//        }
        //ניתן הפנייה לאובייקטים שבכל תא
        TextView tvTitle = view.findViewById(R.id.tvTitle);
        TextView tvSubTitle = view.findViewById(R.id.tvSubTitle);
        TextView tvWL_STR = view.findViewById(R.id.tvWL_STR);
        TextView tvPrice = view.findViewById(R.id.tvTime);
        //TextView tvPrice = view.findViewById(R.id.tvPrice);
        //ImageView ivProduct = view.findViewById(R.id.ivProduct);

        //נשלוף איבר במיקום position מהרשימה
        Record temp = objects.get(position);

        //ניתן לכל אובייקט בתא את הערכים מהרשימה
        tvTitle.setText(temp.getName());
        tvSubTitle.setText(temp.getNickName());
        tvPrice.setText(String.valueOf(temp.getTime()));
        tvWL_STR.setText(temp.getWinner());
        //tvPrice.setText(String.valueOf(temp.getPrice()));
        //   ivProduct.setImageBitmap(temp.getBitmap());
        String x;
//        if (x.get)

        if (temp.getWinner().equals("Losser") ) {
            Log.e("nadav", SaveSettings.getStrWoLC());
            Log.e("nadav1", String.valueOf(position));
            view.setBackgroundColor(Color.parseColor("#3F51B5"));
        } else {
            view.setBackgroundColor(Color.parseColor("#492B7C"));
        }




        return view;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
//    @Override
//    public View getView (int position, @Nullable View convertView,
//     View view = super.getView (position, convertView, parent);
//    if (position %2 == 1){
//         (getResources ().getColer( android.R.color.holo red dark
//         ));
//            else {
//                 view.setBackgroundColor (getResources ().getCelor( android.R.color.holo red light
//    return view;
//    }
//            }
//public View getView


