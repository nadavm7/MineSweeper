package com.example.kingmanne;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Model {//MineGrid
    private final List<Cell> cells;
    private final int size;

    public Model(int size) {
        this.size = size;
        this.cells = new ArrayList<>();
        for (int i = 0; i < Math.pow(size, 2); i++) {
            cells.add(new Cell(Cell.BLANK));//מאתחל לוח ריק
        }
    }

    public void generateGrid(int totalBombs) { //ממקם פצצות באופן אוטומטי
        int bombsPlaced = 0;
        while (bombsPlaced < totalBombs) {// WHILE זה רץ עד שמיקם פצצות כמספר שהוכנס כפרמטר
            int x = new Random().nextInt(size); //מספר רנדומאלי של ערך X
            int y = new Random().nextInt(size);// מספר רנדומאלי של ערך Y

            if (cellAt(x, y).getValue() == Cell.BLANK) {// בודק אם התא ריק והוא לא כבר פצצה
//                cells.set(x + (y * size), new Cell(Cell.BOMB));// הופך את התא לפצצה
                //cells.set(x + (y * size), new BombCell()); //Cell(Cell.BOMB));// הופך את התא לפצצה
                cells.set(x + (y * size), new BombCell()); //Cell(Cell.BOMB));// הופך את התא לפצצה
                bombsPlaced++;//מגדיל את מספר הפצצות שהונחו ב-1
            }
        }

        for (int x = 0; x < size; x++) {//מחשב איזה מספר צריך להופיע
            for (int y = 0; y < size; y++) {// לולאה בתוך לולאה
                if (cellAt(x, y).getValue() != Cell.BOMB) {//בודק לכל תא שהערך שלו הוא לא פצצה
                    List<Cell> adjacentCells = adjacentCells(x, y);
                    int countBombs = 0;
                    for (Cell cell : adjacentCells) {
                        if (cell.getValue() == Cell.BOMB) {//סופר כמה פצצות ישלי מסביב
                            countBombs++;
                        }
                    }
                    if (countBombs > 0) {
//                        cells.set(x + (y * size), new Cell(countBombs));
                        cells.set(x + (y * size), new GrideCell(countBombs));
                    }
                }
            }
        }
    }

    public Cell cellAt(int x, int y) {
        if (x < 0 || x >= size || y < 0 || y >= size) {//בודק שהקורדינטות של התא תקינות
            return null;
        }
        return cells.get(x + (y * size));//מחזיר את המיקום ברצף
    }

    public List<Cell> adjacentCells(int x, int y) {//תאים סמוכים
        List<Cell> adjacentCells = new ArrayList<>();//יצירת רשימה חדשה

        List<Cell> cellsList = new ArrayList<>();//רשימת תאים סמוכים *זמנית
        cellsList.add(cellAt(x - 1, y));//מלמטה
        cellsList.add(cellAt(x + 1, y));//מעל
        cellsList.add(cellAt(x - 1, y - 1));//למטה שמאל
        cellsList.add(cellAt(x, y - 1));//למטה
        cellsList.add(cellAt(x + 1, y - 1));//למטה ימין
        cellsList.add(cellAt(x - 1, y + 1));//למעלה שמאל
        cellsList.add(cellAt(x, y + 1));//מימין
        cellsList.add(cellAt(x + 1, y + 1));//מעל

        for (Cell cell : cellsList) {
            if (cell != null) {//בודק אם התא הוא לא NULL אני מוסיף אותו לרשימת התאים הסמוכים
                adjacentCells.add(cell);//הבדיקה הזו נועדה לא לחרוג מגבולות הלוח
            }
        }

        return adjacentCells;// מוחזרת רשימה של תאים הסמוכים שהם לא NULL
    }

    public int toIndex(int x, int y) {
        return x + (y * size);
    }// רשימה אחת רצופה ולא מערך דו מימדי

    public int[] toXY(int index) {
        int y = index / size;
        int x = index - (y * size);//  שנוכל למצוא את התא המתאים  X ו Y  ממיר אינדקס לקורדינטות
        return new int[]{x, y};//מחזירה מערך שלם
    }

    public void revealAllBombs() {
        for (Cell c : cells) {
            if (c.isBoomb()) {
                c.setRevealed(true);
            }
        }
    }
    public List<Cell> getCells() {
        return cells;
    }
}
