package com.example.kingmanne;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import io.github.muddz.styleabletoast.StyleableToast;

public class CameraActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST = 1;
    private static final int SELECT_PHOTO = 2;
    private static final String PIC_APP_FILE_NAME = "MyPic.png";
    private static final String PIC_GALLERY_FILE_NAME = "MyGalleryPic";
    private final BroadcastReceiver MyReceiver = null;
    private final String[] permissions = new String[]{
            Manifest.permission.CAMERA
            , Manifest.permission.READ_EXTERNAL_STORAGE
            , Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    EditText sub, con;
    Bitmap imageBitmap;
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        iv = findViewById(R.id.iv);
        sub = findViewById(R.id.tvSub);
        con = findViewById(R.id.tvCon);

    }

    public void send(View view) {
        if (!sub.getText().toString().isEmpty() && !con.getText().toString().isEmpty()) {
            String[] emails = {"nadavmana@gmail.com"};
            Intent emailSelectorIntent = new Intent(Intent.ACTION_SENDTO);
            emailSelectorIntent.setData(Uri.parse("mailto:"));
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, emails);
            intent.putExtra(Intent.EXTRA_SUBJECT, sub.getText().toString());
            intent.putExtra(Intent.EXTRA_TEXT, con.getText().toString());
            intent.setSelector(emailSelectorIntent);
            String path = MediaStore.Images.Media.insertImage(getContentResolver(), imageBitmap, "title", null);
            System.out.println(path);
            if (path != null) {
                Uri screenshotUri = Uri.parse(path);
                intent.putExtra(Intent.EXTRA_STREAM, screenshotUri);
            }
            startActivity(Intent.createChooser(intent, "Send Email"));
        } else {

            StyleableToast.makeText(this,"this is Empty" , R.style.eeror).show();
        }

    }


    public void addPic(View view) {
        final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setMessage("pictures from gallery OR camera:");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                } catch (Exception e) {

                    Log.e("nadav", e.toString());
                }
            }

        });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "GALLERY", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                try {
                    startActivityForResult(photoPickerIntent, SELECT_PHOTO);
                } catch (Exception e) {
                    Log.e("nadav nadav", "Exception: " + Log.getStackTraceString(e));
                }
            }

        });
        alertDialog.show();


    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            imageBitmap = (Bitmap) data.getExtras().get("data");
            iv.setImageBitmap(imageBitmap);
            savePic();
            saveImageToGallery();
        }
        if (requestCode == SELECT_PHOTO && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            try {
                imageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                iv.setImageBitmap(imageBitmap);
                //savePic();
            } catch (IOException e) {
                Log.e("nadav1", "Exception: " + Log.getStackTraceString(e));
            }
        }

    }

    private void savePic() {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(PIC_APP_FILE_NAME, Context.MODE_PRIVATE);
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            Log.e("nadav b ", "Exception: " + Log.getStackTraceString(e));
        }
    }

    public Bitmap loadPic(String fileName) {
        FileInputStream fileInputStream;
        Bitmap bitmap = null;
        try {
            fileInputStream = openFileInput(fileName);
            bitmap = BitmapFactory.decodeStream(fileInputStream);
        } catch (FileNotFoundException e) {
            Log.e("best nadav", "Exception: " + Log.getStackTraceString(e));
        }
        return bitmap;
    }

    //galleryAddPic
    private void saveImageToGallery() {
        MediaStore.Images.Media.insertImage(getContentResolver(), imageBitmap, PIC_GALLERY_FILE_NAME, "example");
    }

}




