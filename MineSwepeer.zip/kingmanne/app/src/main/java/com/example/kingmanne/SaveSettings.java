package com.example.kingmanne;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.content.Context;

public class SaveSettings {

    private static SharedPreferences sp;

    private static boolean bVibrate, bSound, bBGMusic;
    private static String stronf = "strKeysonf";
    private static String strWoLC = "strKeyWoLC";
    private static String strKeyTimer = "strKeyTimer";
    final String strSPFileName = "settings_files";
    final String strKeysVibrate = "keyVibrate";
    final String strKeysSound = "keySound";
    final String strKeysBGMusic = "keyBackgroundMusic";
    final String strKeysonf = "keyonf";


    static String strKeyWoLC = "keyWoLC";


    static Integer intTimer = 0;


    public SaveSettings(Context context) {
        if (sp != null) {
            return;
        }
        sp = context.getSharedPreferences(strSPFileName, Context.MODE_PRIVATE);
        bVibrate = sp.getBoolean(strKeysVibrate, true);
        bSound = sp.getBoolean(strKeysSound, true);
        bBGMusic = sp.getBoolean(strKeysBGMusic, false);
        stronf = sp.getString(strKeysonf, "off");

        strKeyWoLC = sp.getString(strKeyWoLC, "Losser");
        intTimer = sp.getInt(strKeyTimer, 0);
    }

    public SaveSettings(AirplaneModeReceiver airplaneModeReceiver) {

    }

    public SaveSettings(RecordAdapter recordAdapter) {

    }

    public static String getStrWoLC() {
        return strWoLC;
    }
    public static String getKeyStrWoLC() {
        return strKeyWoLC;
    }

    public static void setStrWoLC(String strWoLC) {
        SaveSettings.strWoLC = strWoLC;
    }

    public void setStrKeyWoLC(String strKeyWoLC) {
        this.strKeyWoLC = strKeyWoLC;
    }

    public String getStrKeysonf() {
        return stronf;
    }

    public void setIntTimer(Integer intTimer) {
        this.intTimer = intTimer;
    }

    public static Integer getIntTimer() {
        return intTimer;
    }

    public void setStrKeysonf(String stronf) {
        SaveSettings.stronf = stronf;
    }

    public boolean isbVibrate() {
        return bVibrate;
    }

    public void setbVibrate(boolean bVibrate) {
        SaveSettings.bVibrate = bVibrate;
    }

    public boolean isbSound() {
        return bSound;
    }

    public void setbSound(boolean bSound) {
        SaveSettings.bSound = bSound;
    }

    public boolean isbBGMusic() {
        return bBGMusic;
    }

    public void setbBGMusic(boolean bBackgroundMusic) {
        SaveSettings.bBGMusic = bBackgroundMusic;
    }


    @SuppressLint("NotConstructor")
    public void SaveSettings() {
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(strKeysVibrate, bVibrate);
        editor.putBoolean(strKeysSound, bSound);
        editor.putBoolean(strKeysBGMusic, bBGMusic);
        editor.putString(strKeysonf, stronf);

        editor.putString(strKeyWoLC, strWoLC);
        editor.putInt(strKeyTimer, intTimer);

        editor.commit();
    }
}



