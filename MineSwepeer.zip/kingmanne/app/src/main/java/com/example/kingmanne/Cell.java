package com.example.kingmanne;

public class Cell extends GeneralCell{
//    public static final int BOMB = -1;
//    public static final int BLANK = 0;
//    //private boolean revealed;
    private final int value;

    public Cell(int value) {
        this.setFlagged(false);
        this.setRevealed(false);
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public boolean isRevealed() {
        return super.revealed;
    }

    public void setRevealed(boolean revealed) {
       // this.setRevealed(revealed) ;
       // revealed=revealed ;
        super.revealed = revealed;
    }

    public boolean isFlagged() {
        return super.flagged;
    }

    public void setFlagged(boolean flagged) {
        //this.isFlagged(flagged);
        super.flagged = flagged;
    }

     public boolean isBoomb() {
        return (this.value == Cell.BOMB);
     }

}
//private boolean isRevealed;//האם התא התגלה או לא
//private boolean isFlagged;
//    private boolean isRevealed;//האם התא התגלה או לא
//    private boolean isFlagged;

//    public Cell(boolean isRevealed, boolean isFlagged,int value) {
//        this.isRevealed = isRevealed;
//        this.isFlagged = isFlagged;
//        this.value = value;
//    }