package com.example.kingmanne;

public class GrideCell  extends Cell{

    public GrideCell(int value) {
        super(value);
    }
    public int getValue() {
        return super.getValue();
    }

    public boolean isRevealed() {
        return super.isRevealed();
    }

    public void setRevealed(boolean revealed) {
        super.setRevealed(revealed) ;
    }

    public boolean isFlagged() {
        return super.isFlagged();
    }

    public void setFlagged(boolean flagged) {
        super.setFlagged(flagged);
    }
}
