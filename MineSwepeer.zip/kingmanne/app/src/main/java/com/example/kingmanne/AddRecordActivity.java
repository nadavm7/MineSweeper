package com.example.kingmanne;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import io.github.muddz.styleabletoast.StyleableToast;

public class AddRecordActivity extends AppCompatActivity {

    EditText etName;
    EditText etNickName;
    TextView tvWinner;
    //String strKeyWoLC;
    Integer spTime;
    TextView tvTime;
    private TextView WorL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);

        WorL = findViewById(R.id.tvDisplay);

        etName = findViewById(R.id.etName);
        etNickName = findViewById(R.id.etNickName);
        tvWinner = findViewById(R.id.tvWinner);
        tvTime = findViewById(R.id.tvTime);

//       etPrice1 =findViewById(R.id.etPrice);
//        etPrice1.setText(SaveSettings.getIntTimer());
    }

    @Override
    public void onBackPressed(){
        StyleableToast.makeText(getApplicationContext(), "you must to click save", R.style.eeror).show();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        String i = intent.getStringExtra("gh");

        if (i.equals("Losser")) {
            WorL.setText("Add new Looser to the score-board");
            tvWinner.setText("Losser");

        } else {
            WorL.setText("Add new Winner to the score-board ");
            tvWinner.setText("Winner");
        }

        spTime = SaveSettings.getIntTimer();
        tvTime.setText(spTime + "");
    }

    public void save(View view) {


        StyleableToast.makeText(getApplicationContext(), "Saving the record...", R.style.secssus).show();

        // Toy t=new Toy(Price,TItle,STitle);
        RecordDataBase tt = new RecordDataBase(this);
        tt.createRecord(new Record(spTime, etName.getText().toString(), etNickName.getText().toString(), tvWinner.getText().toString()));//strKeyWoLC.getText().toString());
        //tt.createRecord(new Record(Price, TItle.getText().toString(), STitle.getText().toString(),strKeyWoLC.getText().toString()));
        // tt.createRecord(new Record(Integer.parseInt(Price.getText().toString()), TItle.getText().toString(), STitle.getText().toString()));
        //TODO SET
//
//            if(!question.getText().toString().isEmptg3.getText().toString(), hint.getText().toString());
//                QuestionDataBase questionDataBase = new QuestionDataBase(this);
//                questionDataBase.setQuestion(q);
//                finish();
//            }
//            else
//            {
//                Toast.makeText(this, "you forget to write all", Toast.LENGTH_SHORT).show();
//            }
        finish();
    }

    public void back(View view) {
        finish();
    }

}
