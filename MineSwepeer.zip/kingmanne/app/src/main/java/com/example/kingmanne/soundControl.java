package com.example.kingmanne;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;


public class soundControl {
    private final SoundPool soundPool;
    private final int sound1;


    public soundControl(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder().setMaxStreams(20).build();
        } else
            soundPool = new SoundPool(20, AudioManager.STREAM_MUSIC, 1);

        //sound1 = soundPool.load(context, R.raw.go_sleep, 1);
        sound1 = soundPool.load(context, R.raw.indila_ainsi, 1);
    }
    public void playSound1() {
        soundPool.play(sound1, 1, 1, 1, 0, 1);
    }

}

