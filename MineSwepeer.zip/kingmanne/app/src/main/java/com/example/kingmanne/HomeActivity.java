package com.example.kingmanne;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    Button successToast, errorToast, warningToast, infoToast;
    private Button register;
    private Button Login;
    //  Button b1, b2;
//    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

//        context = this;
//        b1 = findViewById(R.id.button);
//        b2 = findViewById(R.id.button2);
//        b1.setOnClickListener(this);
//        b2.setOnClickListener(this);
    }
    public void loggg(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void regggg(View view) {
        Intent intent = new Intent(this, registerActivity.class);
        startActivity(intent);
    }
}

//    @Override
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.button:
//                new FancyGifDialog.Builder(this)
//                        .setTitle("Granny eating chocolate dialog box")
//                        .setMessage("This is a granny eating chocolate dialog box. This library is used to help you easily create fancy gify dialog.")
//                        .setNegativeBtnText("Cancel")
//                        .setTitleTextColor(R.color.titleText)
//                        .setDescriptionTextColor(R.color.descriptionText)
//                        .setPositiveBtnBackground(R.color.positiveButton)
//                        .setPositiveBtnText("Ok")
//                        .setNegativeBtnBackground(R.color.negativeButton)
//                        .setGifResource(R.drawable.gif1)
//                        .isCancellable(true)
//                        .OnPositiveClicked(new FancyGifDialogListener() {
//                            @Override
//                            public void OnClick() {
//                                toaster("ok");
//                            }
//                        })
//                        .OnNegativeClicked(new FancyGifDialogListener() {
//                            @Override
//                            public void OnClick() {
//                                toaster("cancel");
//                            }
//                        })
//                        .build();
//                break;
//            case R.id.button2:
//                new FancyGifDialog.Builder(this)
//                        .setTitle(R.string.from_resources)
//                        .setMessage(R.string.description_from_resources)
//                        .setNegativeBtnText(android.R.string.cancel)
//                        .setTitleTextColor(R.color.titleText)
//                        .setDescriptionTextColor(R.color.descriptionText)
//                        .setPositiveBtnBackground(R.color.positiveButton)
//                        .setPositiveBtnText(android.R.string.ok)
//                        .setNegativeBtnBackground(R.color.negativeButton)
//                        .setGifResource(R.drawable.gif1)
//                        .isCancellable(true)
//                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
//                            @Override
//                            public void onCancel(DialogInterface dialogInterface) {
//                                toaster("Cancelled");
//                            }
//                        })
//                        .OnPositiveClicked(new FancyGifDialogListener() {
//                            @Override
//                            public void OnClick() {
//                                toaster("Ok");
//                            }
//                        })
//                        .OnNegativeClicked(new FancyGifDialogListener() {
//                            @Override
//                            public void OnClick() {
//                                toaster("Cancel");
//                            }
//                        })
//                        .build();
//                break;
//        }
//
//
//    }
//
//    private void toaster(String message) {
//        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
//    }
//
//    @Override
//    public void onPointerCaptureChanged(boolean hasCapture) {
//
//    }


//
//        register = findViewById(R.id.TORegist);
//        Login = findViewById(R.id.TOLogin);
//        register.setOnClickListener(this);
//        Login.setOnClickListener(this);

//        findViewById(R.id.successToast).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view){
//                showSuccessAlertDialog();
//            }
//        });

//        findViewById(R.id.infoToast).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view){
//                showInfoAlertDialog();
//            }
//        });
//
//        findViewById(R.id.warningToast).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view){
//                showWarringAlertDialog();
//            }
//        });
//
//        findViewById(R.id.errorToast).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view){
//                showErrorAlertDialog();
//            }
//        });

//
//    private void showSuccessAlertDialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this , R.style.AlertDialogTheme);
//        View view = LayoutInflater.from(HomeActivity.this).inflate(
//                R.layout.layout_sucess_dialog,findViewById(R.id.layoutDialogContainer)
//        );
//        builder.setView(view);
//        ((TextView) view.findViewById(R.id.textTitle)).setText("Success Title");
//        ((TextView) view.findViewById(R.id.textMassage)).setText("nadav the king");
//        ((Button) view.findViewById(R.id.buttonAction)).setText("check button");
//        ((ImageView) view.findViewById(R.id.imageIcon)).setImageResource(R.drawable.done);
//
//        final AlertDialog alertDialog = builder.create();
//
//        view.findViewById(R.id.buttonAction).setOnClickListener(new View.OnClickListener() {
//        @Override
//                public void onClick(View view) {
//            alertDialog.dismiss();
//            Toast.makeText(HomeActivity.this, "Success", Toast.LENGTH_SHORT).show();
//        }
//        });
//
//        if(alertDialog.getWindow() != null){
//            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//        }
//        alertDialog.show();
//    }


//    private void showInfoAlertDialog() {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this , R.style.AlertDialogTheme);
//        View view = LayoutInflater.from(HomeActivity.this).inflate(
//                R.layout.layout_sucess_dialog,findViewById(R.id.layoutDialogContainer)
//        );
//        builder.setView(view);
//        ((TextView) view.findViewById(R.id.textTitle)).setText("Success Title");
//        ((TextView) view.findViewById(R.id.textMassage)).setText("nadav the king");
//        ((Button) view.findViewById(R.id.buttonAction)).setText("check button");
//        ((ImageView) view.findViewById(R.id.imageIcon)).setImageResource(R.drawable.done);
//
//        final AlertDialog alertDialog = builder.create();
//
//        view.findViewById(R.id.buttonAction).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                alertDialog.dismiss();
//                Toast.makeText(HomeActivity.this, "Success", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        if(alertDialog.getWindow() != null){
//            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//        }
//        alertDialog.show();
//    }


//    private void showWarringAlertDialog() {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this , R.style.AlertDialogTheme);
//        View view = LayoutInflater.from(HomeActivity.this).inflate(
//                R.layout.layout_warning_dialog,findViewById(R.id.layoutDialogContainer)
//        );
//        builder.setView(view);
//        ((TextView) view.findViewById(R.id.textTitle)).setText("Waring Title");
//        ((TextView) view.findViewById(R.id.textMassage)).setText("nadav the king");
//        ((Button) view.findViewById(R.id.buttonAction)).setText("check button");
//        ((ImageView) view.findViewById(R.id.imageIcon)).setImageResource(R.drawable.done);
//
//        final AlertDialog alertDialog = builder.create();
//
//        view.findViewById(R.id.buttonAction).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                alertDialog.dismiss();
//                Toast.makeText(HomeActivity.this, "Warning", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        if(alertDialog.getWindow() != null){
//            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//        }
//        alertDialog.show();
//    }
//
//
//
//    private void showErrorAlertDialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this , R.style.AlertDialogTheme);
//        View view = LayoutInflater.from(HomeActivity.this).inflate(
//                R.layout.layout_error_dialog,findViewById(R.id.layoutDialogContainer)
//        );
//        builder.setView(view);
//        ((TextView) view.findViewById(R.id.textTitle)).setText("Error Title");
//        ((TextView) view.findViewById(R.id.textMassage)).setText("nadav the king");
//        ((Button) view.findViewById(R.id.buttonAction)).setText("check button");
//        ((ImageView) view.findViewById(R.id.imageIcon)).setImageResource(R.drawable.done);
//
//        final AlertDialog alertDialog = builder.create();
//
//        view.findViewById(R.id.buttonAction).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                alertDialog.dismiss();
//                Toast.makeText(HomeActivity.this, "Error", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        if(alertDialog.getWindow() != null){
//            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//        }
//        alertDialog.show();
//    }


//        successToast = findViewById(R.id.successToast);
//        errorToast = findViewById(R.id.errorToast);
//        warningToast = findViewById(R.id.warningToast);
//        infoToast = findViewById(R.id.infoToast);
//
//        successToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.createToast(HomeActivity.this, "Success Toast",
//                        MotionToast.TOAST_SUCCESS,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(HomeActivity.this, R.font.helvetica_regular));
//            }
//        });
//
//        errorToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.createColorToast(HomeActivity.this, "Error Toast",
//                        MotionToast.TOAST_ERROR,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(HomeActivity.this, R.font.helvetica_regular));
//            }
//        });
//
//        warningToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.darkToast(HomeActivity.this, "Warning Toast",
//                        MotionToast.TOAST_WARNING,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(HomeActivity.this, R.font.helvetica_regular));
//            }
//        });
//
//        infoToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.darkColorToast(HomeActivity.this, "Info Toast",
//                        MotionToast.TOAST_INFO,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(HomeActivity.this, R.font.helvetica_regular));
//            }
//        });
//    }


//    @Override
//    public void onClick(View view) {
//        Intent intent = new Intent(this, LoginActivity.class);
//        startActivity(intent);
//    }
