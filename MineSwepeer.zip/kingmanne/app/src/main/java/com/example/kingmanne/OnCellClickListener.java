package com.example.kingmanne;

public interface OnCellClickListener {
    void cellClick(Cell cell);// מאזין לפרמטר של תא
    // מאזין לכל הלחיצות כלומר לכל אריח במשחק
}
