package com.example.kingmanne;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import io.github.muddz.styleabletoast.StyleableToast;

public class MainActivity extends AppCompatActivity implements OnCellClickListener {

    public static final long TIMER_LENGTH = 999000L;    // 999 seconds in milliseconds
    public static final int BOMB_COUNT = 10;
    public static final int GRID_SIZE = 10;
    BroadcastReceiver br;
    private MineGridRecyclerAdapter mineGridRecyclerAdapter;
     RecyclerView grid;
     TextView smiley, timer, flag, flagsLeft;
    private SaveSettings save_settings;
     soundControl soundControl;
    private Controller mineSweeperGame;
     Vibrator vibrator;
    private CountDownTimer countDownTimer;
     Intent musicIntent;
    private int secondsElapsed;
    private boolean timerStarted;
    SaveSettings saveSettings;
     TextView WorL;

//todo vbrate,record list-timer+ifwiinercolor , brodcastreciver ,dialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WorL = findViewById(R.id.tvDisplay);
        //br1 = findViewById(R.id.button2);
        //br1.setVisibility(View.INVISIBLE);
        br = new AirplaneModeReceiver();

        save_settings = new SaveSettings(this);
        musicIntent = new Intent(this, MusicServise.class);
        startService(musicIntent);
        soundControl = new soundControl(this);
        if (save_settings.isbBGMusic()) {
            soundControl.playSound1();
        }

//        AirplaneModeReceiver receiver = new AirplaneModeReceiver();
//
//        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
//        this.registerReceiver(receiver,intentFilter);

        grid = findViewById(R.id.activity_main_grid);//מאזין לכל הלוח
        grid.setLayoutManager(new GridLayoutManager(this, 10));//  יוצר לווח ומעביר לו כפרמטר את הגודל שהוא 10 10
        //grid.setEnabled(false);
        timer = findViewById(R.id.activity_main_timer);
        timerStarted = false;
        countDownTimer = new CountDownTimer(TIMER_LENGTH, 1000) {
            public void onTick(long millisUntilFinished) {
                secondsElapsed += 1;
                timer.setText(String.format("%03d", secondsElapsed));
            }

            public void onFinish() {
                mineSweeperGame.outOfTime();

                StyleableToast.makeText(getApplicationContext(),"Game Over: Timer Expired", R.style.eeror).show();

                mineSweeperGame.getMineGrid().revealAllBombs();
                mineGridRecyclerAdapter.setCells(mineSweeperGame.getMineGrid().getCells());
            }
        };

        flagsLeft = findViewById(R.id.activity_main_flagsleft);
        //flag.setEnabled(false);
        //flagLeft.setEnabled(false);
        mineSweeperGame = new Controller(GRID_SIZE, BOMB_COUNT);
        flagsLeft.setText(String.format("%03d", mineSweeperGame.getNumberBombs() - mineSweeperGame.getFlagCount()));
        mineGridRecyclerAdapter = new MineGridRecyclerAdapter(mineSweeperGame.getMineGrid().getCells(), this);
        grid.setAdapter(mineGridRecyclerAdapter);

        smiley = findViewById(R.id.activity_main_smiley);
        smiley.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mineSweeperGame = new Controller(GRID_SIZE, BOMB_COUNT);
                mineGridRecyclerAdapter.setCells(mineSweeperGame.getMineGrid().getCells());
                timerStarted = false;
                countDownTimer.cancel();
                secondsElapsed = 0;
                timer.setText(R.string.default_count);
                flagsLeft.setText(String.format("%03d", mineSweeperGame.getNumberBombs() - mineSweeperGame.getFlagCount()));
            }
        });

        flag = findViewById(R.id.activity_main_flag);
        flag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (timerStarted) {
                    //mineSweeperGame.isFlagMode()=false;//flag
                    mineSweeperGame.toggleMode();
                    if (mineSweeperGame.isFlagMode()) {
                        GradientDrawable border = new GradientDrawable();
                        border.setColor(0xFFFFFFFF);
                        border.setStroke(10, 0xFF000000);
                        //flag.setBackground(R.drawable.ic_baseline_flag_24);
                        flag.setBackground(border);
                    } else {
                        GradientDrawable border = new GradientDrawable();
                        border.setColor(0xFFFFFFFF);
                        flag.setBackground(border);
                    }
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        registerReceiver(br, new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED));
        SaveSettings saveSettings = new SaveSettings(this);
        //String onf = saveSettings.getStrKeysonf();
//        if (saveSettings.getStrKeysonf().equals("on")) {
//            WorL.setText("air p mode is onnnnnnnnnnn");
////            br5.setBackground(getDrawable(dgi));
////            TextView textView = (TextView) findViewById(R.id.myTxtView);
//            br5.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_baseline_airplanemode_active_24, 0, 0, 0);
//        } else {
//            WorL.setText("air p mode is offfffffffff ");
//            br5.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_baseline_nnairplanemode_inactive_24, 0, 0, 0);
//        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(br);
    }


    @Override
    public void cellClick(Cell cell) {
        mineSweeperGame.handleCellClick(cell);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        flagsLeft.setText(String.format("%03d", mineSweeperGame.getNumberBombs() - mineSweeperGame.getFlagCount()));
        Intent intent = new Intent();
        if (!timerStarted) {
            countDownTimer.start();
            timerStarted = true;
        }

        if (mineSweeperGame.isGameOver()) {
            countDownTimer.cancel();
            if (save_settings.isbVibrate())
                vibrator.vibrate(200);

            StyleableToast.makeText(getApplicationContext(),"Game Over", R.style.eeror).show();
            saveSettings = new SaveSettings(this);
            //String onf = saveSettings.getStrKeysonf();
            grid.setEnabled(false);
                saveSettings.setStrWoLC("Losser");
            saveSettings.setIntTimer(secondsElapsed);
            // countDownTimer
            //todo Timer
            intent = new Intent(this, AddRecordActivity.class);
            //intent.putExtra("gh", (Parcelable) countDownTimer);
            String WL = "Losser";
            intent.putExtra("gh", WL);

            mineSweeperGame.getMineGrid().revealAllBombs();
            startActivity(intent);
        }

        if (mineSweeperGame.isGameWon()) {
            countDownTimer.cancel();
            //String Ti = String.valueOf(countDownTimer);
            //saveSettings.setIntTimer(countDownTimer);
            saveSettings.setStrWoLC("Winner");

            saveSettings.setIntTimer(secondsElapsed);


            StyleableToast.makeText(getApplicationContext(),"Game Won", R.style.secssus).show();
            intent = new Intent(this, AddRecordActivity.class);
            String Www = "Winner";
            intent.putExtra("gh", Www);
            mineSweeperGame.getMineGrid().revealAllBombs();
            startActivity(intent);
        }

        mineGridRecyclerAdapter.setCells(mineSweeperGame.getMineGrid().getCells());
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) { // תפריט בצד המסך
        //return super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_manu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {//כפתורים לכל מסך בתפריט
        super.onOptionsItemSelected(item);
        int id = item.getItemId();
        switch (id) {
            case R.id.item2:
                Intent intent = new Intent(this, RecordListActivity.class);
                startActivity(intent);
                break;
//            case R.id.item3:
//                Intent intentPList = new Intent(this, PlayerListActivity.class);
//                startActivity(intentPList);
//                break;
            case R.id.item_settings:
                Intent intentSettings = new Intent(this, SettingsActivity.class);
                startActivity(intentSettings);
                //finish();
                break;
//            case R.id.item_about:
//                Intent intentTS = new Intent(this, AddRecordActivity.class);
//                startActivity(intentTS);
//                break;
            case R.id.item1:
                Intent intentCamera = new Intent(this, CameraActivity.class);
                startActivity(intentCamera);
                break;
            case R.id.subitem1:
                Intent intentLike = new Intent(this, InternetLike.class);
                startActivity(intentLike);
                break;

//            case R.id.Login:
//                Intent intentLogin = new Intent(this, LoginActivity.class);
//                startActivity(intentLogin);
//                break;
//            case R.id.register:
//                Intent intentregi = new Intent(this, registerActivity.class);
//                startActivity(intentregi);
//                break;
        }
        return true;
    }
}
