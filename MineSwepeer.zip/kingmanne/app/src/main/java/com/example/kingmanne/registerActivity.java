package com.example.kingmanne;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import io.github.muddz.styleabletoast.StyleableToast;


public class registerActivity extends AppCompatActivity implements View.OnClickListener {
    EditText email;
    private EditText pass;
    // private String emaill1;
    private Button register;
    private FirebaseAuth auth;
    //private Button successToast, errorToast, warningToast, infoToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        pass = findViewById(R.id.mypass);
        email = findViewById(R.id.etemail);
        String st = email.getText().toString();
        register = findViewById(R.id.signinn);
        register.setOnClickListener(this);

        auth = FirebaseAuth.getInstance();
        //email=emaill1;
//        findViewById(R.id.signinn).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                showWarringAlertDialog();
//            }
//        });

    }

    @Override
    public void onClick(View view) {

        String txt_email = email.getText().toString();

        String txt_pass = pass.getText().toString().trim();

        if (TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_pass)) {

            StyleableToast.makeText(this,"Empty credentials!", R.style.eeror).show();
            //showWarringAlertDialog();

        } else if (txt_pass.length() < 6) {

            StyleableToast.makeText(this,"Password too short!", R.style.Warning).show();
        } else {
            registerUser(txt_email, txt_pass);
//            showWarringAlertDialog();
        }

    }

    private void registerUser(String txt_email, String txt_pass) {
        auth.createUserWithEmailAndPassword(txt_email, txt_pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    StyleableToast.makeText(registerActivity.this,"Registering user successful!", R.style.secssus).show();

                    startActivity(new Intent(registerActivity.this, MainActivity.class));
                    finish();
                } else {
                    StyleableToast.makeText(registerActivity.this,"Registration failed!" , R.style.eeror).show();
                }
            }
        });
    }


}
//        successToast = findViewById(R.id.successToast);
//        errorToast = findViewById(R.id.errorToast);
//        warningToast = findViewById(R.id.warningToast);
//        infoToast = findViewById(R.id.infoToast);
//
//        successToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.createToast(registerActivity.this, "Success Toast",
//                        MotionToast.TOAST_SUCCESS,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(registerActivity.this, R.font.helvetica_regular));
//            }
//        });
//
//        errorToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.createColorToast(registerActivity.this, "Error Toast",
//                        MotionToast.TOAST_ERROR,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(registerActivity.this, R.font.helvetica_regular));
//            }
//        });
//
//        warningToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.darkToast(registerActivity.this, "Warning Toast",
//                        MotionToast.TOAST_WARNING,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(registerActivity.this, R.font.helvetica_regular));
//            }
//        });
//
//        infoToast.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                MotionToast.Companion.darkColorToast(registerActivity.this, "Info Toast",
//                        MotionToast.TOAST_INFO,
//                        MotionToast.GRAVITY_BOTTOM,
//                        MotionToast.LONG_DURATION,
//                        ResourcesCompat.getFont(registerActivity.this, R.font.helvetica_regular));
//            }
//        });

//    private void showWarringAlertDialog() {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(registerActivity.this, R.style.AlertDialogTheme);
//        View view = LayoutInflater.from(registerActivity.this).inflate(
//                R.layout.layout_warning_dialog, findViewById(R.id.layoutDialogContainer)
//        );
//        builder.setView(view);
//        ((TextView) view.findViewById(R.id.textTitle)).setText("Waring Title");
//        ((TextView) view.findViewById(R.id.textMassage)).setText("nadav the king");
//        ((Button) view.findViewById(R.id.buttonAction)).setText("check button");
//        ((ImageView) view.findViewById(R.id.imageIcon)).setImageResource(R.drawable.done);
//
//        final AlertDialog alertDialog = builder.create();
//
//        view.findViewById(R.id.buttonAction).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                alertDialog.dismiss();
//                Toast.makeText(registerActivity.this, "Warning", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        if (alertDialog.getWindow() != null) {
//            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
//        }
//        alertDialog.show();
//    }
