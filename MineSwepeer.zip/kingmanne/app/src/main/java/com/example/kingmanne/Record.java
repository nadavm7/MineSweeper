package com.example.kingmanne;

public class Record implements Comparable {
    private int time;
    private String name;
    private String nickName;
    // private Bitmap bitmap;
    private String winner;
    private long Id;

    //private Color coco;

//    public Record(int price, String title, String subTitle, String strKeyWoLC, long Id) {
//        this.price = price;
//        this.title = title;
//        //this.coco= coco;
//        this.subTitle = subTitle;
//        //   this.bitmap = bitmap;
//        this.strKeyWoLC = strKeyWoLC;
//        this.Id = Id;
//    }

    public Record(int time, String name, String nickName, String winner) {
        this.time = time;
        this.name = name;
        //this.coco= coco;
        this.nickName = nickName;
        //   this.bitmap = bitmap;
        this.winner = winner;

    }

    public Record(int time, String name, String nickName, String winner, long id) {
        this.time = time;
        this.name = name;
        this.nickName = nickName;
        this.winner = winner;
        Id = id;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String strKeyWoLC) {
        this.winner = strKeyWoLC;
    }

    // public Bitmap getBitmap() { return bitmap; }
    public long getId() {
        return Id;
    }

    // public void setBitmap(Bitmap bitmap) {this.bitmap = bitmap;}
    public void setId(long Id) {
        this.Id = Id;
    }

    @Override
    public int compareTo(Object o) {
        return this.time - ((Record) o).time;
    }
//@Override
//    public int compareTo(Toy comparestu) {
//            return 1;
//        int compareage=((Toy)comparestu).getStudentage();
//        return this.studentage-compareage;
//    }

//    @Override
//    public int compareTo(Object o) {
//        Toy other =(Toy) o;
//            return this.title.compareToIgnoreCase(((Toy) o) this.title);
//    }
    // lass IgnoreCaseComparator implements Comparator<String> {
//        public int compare(String strA, String strB) {
//            return strA.compareToIgnoreCase(strB);
//        }
//    }
}

