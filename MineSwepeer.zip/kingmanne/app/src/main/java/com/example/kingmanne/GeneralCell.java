package com.example.kingmanne;

abstract public class GeneralCell {
    public static final int BOMB = -1;
    public static final int BLANK = 0;
    public boolean revealed;
    public boolean flagged;
    //private final int value;

  //  public GeneralCell() ;

    public abstract boolean isRevealed();

    public abstract void setRevealed(boolean revealed);

    public abstract boolean isFlagged() ;

    public abstract void setFlagged(boolean flagged) ;

    public abstract boolean isBoomb() ;


}
