package com.example.kingmanne;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, LocationListener {

    Intent musicIntent;
    private Switch swVibrate, swSound, swBGMusic;
    private Vibrator vibrator;
    private SaveSettings saveSettings;
    private TextView latLong, address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        saveSettings = new SaveSettings(this);
        musicIntent = new Intent(this, MusicServise.class);
        initViews();
        latLong = findViewById(R.id.latLong);
        address = findViewById(R.id.Address);
    }

    private void initViews() {
        swVibrate = findViewById(R.id.swSettingsVibrate);
        swVibrate.setOnCheckedChangeListener(this);
        swVibrate.setChecked(saveSettings.isbVibrate());
        swSound = findViewById(R.id.swSettingsSound);
        swSound.setOnCheckedChangeListener(this);
        swSound.setChecked(saveSettings.isbSound());
//            swBGMusic = findViewById(R.id.swSettingsBGMusic);
//            swBGMusic.setOnCheckedChangeListener(this);
//            swBGMusic.setChecked(saveSettings.isbBGMusic());
    }

    public void btnSave(View view) {
        saveSettings.SaveSettings();
        finish();
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (compoundButton.getId() == R.id.swSettingsVibrate && compoundButton.isChecked() == false) {

            saveSettings.setbVibrate(b);
        } else if (compoundButton.getId() == R.id.swSettingsSound && compoundButton.isChecked() == false) {

            stopService(musicIntent);
        } else if (compoundButton.isChecked() == true) {
            saveSettings.setbSound(b);
        }
        if (compoundButton.getId() == R.id.swSettingsSound && compoundButton.isChecked() == false) {

            stopService(musicIntent);
            saveSettings.setbSound(b);
        } else if (compoundButton.getId() == R.id.swSettingsSound && compoundButton.isChecked() == true) {
            startService(musicIntent);
            saveSettings.setbSound(b);

        }

        {
            saveSettings.setbBGMusic(b);
        }
    }

    public void GetLocation(View view) {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            retrieveLocation();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 200);
        }
    }

    @SuppressLint("MissingPermission")
    private void retrieveLocation() {
        LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);

        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, this);

        Location location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        if (location != null) {
            double lat = location.getLatitude();
            double longitude = location.getLongitude();

            Geocoder geocoder = new Geocoder(this, Locale.getDefault());

            try {
                List<Address> addressList = geocoder.getFromLocation(lat, longitude, 1);

                latLong.setText("Lat:" + lat + "Long: " + longitude);
                address.setText(addressList.get(0).getAddressLine(0));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 200 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            retrieveLocation();
        } else {
            latLong.setText("Permission Denied");
            address.setText("Permission Denied");
        }

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

}




