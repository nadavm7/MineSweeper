package com.example.kingmanne;

public class BombCell extends Cell{

    public BombCell() {
       super(Cell.BOMB);
    }
    public int getValue() {
        return super.getValue();
    }


    @Override
    public boolean isBoomb() {
       return super.getValue()== Cell.BOMB;
    }

    public boolean isRevealed() {
    return super.isRevealed();
}

    public void setRevealed(boolean revealed) {
        super.setRevealed(revealed) ;
    }

public boolean isFlagged() {
    return super.isFlagged();
}

    public void setFlagged(boolean flagged) {
        super.setFlagged(flagged);
    }
}
//    public void setFlagged(boolean flagged) {
//        super.setFlagged(flagged);
//    }
//}
//    public boolean isFlagged() {
//        return super.isFlagged();
//    }
//public void setRevealed(boolean revealed) {
//  super.setRevealed(revealed) ;
//}
//    public boolean isRevealed() {
//        return super.isRevealed();
//    }