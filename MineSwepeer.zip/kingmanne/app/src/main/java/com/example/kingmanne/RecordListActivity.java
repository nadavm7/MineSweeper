package com.example.kingmanne;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import io.github.muddz.styleabletoast.StyleableToast;

public class RecordListActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    //ArrayList<Toy> toyList;
    ListView lv;
    RecordAdapter recordAdapter;
    Dialog d;
    RecordDataBase t;
    TextView di;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toy_list);

        t = new RecordDataBase(this);
        recordAdapter = new RecordAdapter(this, 0, 0, t.getAllRecords());
        lv = (ListView) findViewById(R.id.lv);
        //toyList=t.getAllRecords();
        lv.setAdapter(recordAdapter);

      lv.setOnItemClickListener(this);
//        lv.setOnItemLongClickListener(this);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view,final int pos, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(RecordListActivity.this);
                builder.setTitle("delete");
                builder.setMessage("are you want to delete?");
                builder.setCancelable(true);
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        StyleableToast.makeText(getApplicationContext(),"The deletion was successful", R.style.secssus).show();
                        long id=recordAdapter.getItem(pos).getId();
                        t.deleteRecordByRow(id);
//                        recordAdapter = new RecordAdapter(RecordListActivity.this,0,t.updateByRow(recordAdapter));
                        lv.setAdapter(recordAdapter);
                    }
                });
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        StyleableToast.makeText(getApplicationContext(),"You have chosen not to delete", R.style.Warning).show();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            }
        });
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        Bundle b = new Bundle();
        //b.putInt("myTime", t.getAllRecords().get(i).getTime());
        b.putInt("Your Time is :", t.getAllRecords().get(i).getTime());

        //Toast.makeText(this, "N: " + i, Toast.LENGTH_SHORT).show();
        CreatDialog(b);
    }
//    public boolean onItemLongClick (AdapterView< ? > adapterView, View view, int i, long l) {
//        final int deletePosition = i;
//        final AlertDialog alertDialog = new AlertDialog.Builder(RecordListActivity.this).create();
//        alertDialog.setMessage("are you want to delete?");
//        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "NO", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                alertDialog.dismiss();
//            }
//        });
//        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "YES", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        //String Name = t.getAllRecords().get(deletePosition).getName();
//                        long id = t.getAllRecords().get(deletePosition).getId();
//                        t.deleteRecordByRow(id);
//                        update(i);
//                        alertDialog.dismiss();
//
//                    }
//                }
//        );
//        alertDialog.show();
//        return true;
//
//    }
        public void update (int i)
        {
            recordAdapter = new RecordAdapter(this,0, (int) t.getAllRecords().get(i).getId(),t.getAllRecords());
            lv.setAdapter(recordAdapter);
        }
//    public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long l) {
//
//
//        AlertDialog alertDialog = new AlertDialog.Builder(RecordListActivity.this).create();
//        alertDialog.setTitle("Alert");
//
//        alertDialog.setMessage("r u sur?");
//        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        t.getAllRecords().remove(i);
//                        toyAdapter.notifyDataSetChanged();
//                        dialog.dismiss();
//                    }
//                });
//        alertDialog.show();
//        //Toast.makeText(this, "N: " + i, Toast.LENGTH_SHORT).show();
//        return true;
//
//    }
    public void CreatDialog(Bundle c) {
        d = new Dialog(this);
        d.setContentView(R.layout.custium_dialog);
        di = d.findViewById(R.id.edtUname);
        di.setText(c + "");

        d.setTitle("Record");
        //d.setCancelable(true);
        d.show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}



